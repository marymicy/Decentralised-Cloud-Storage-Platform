from app import app

app.run(host = 'localhost', port = '9000',debug=True)